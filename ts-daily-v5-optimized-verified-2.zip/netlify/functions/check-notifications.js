const webpush = require('web-push');
const { getStore } = require('@netlify/blobs');

function store() {
  return getStore({
    name: 'ts-app',
    siteID: process.env.NETLIFY_SITE_ID,
    token: process.env.NETLIFY_AUTH_TOKEN
  });
}

const VAPID_PUBLIC = process.env.VAPID_PUBLIC_KEY;
const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY;
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || 'mailto:example@example.com';
const CRON_SECRET = String(process.env.CRON_SECRET || '').trim();
const CURRENT_ORIGIN = String(process.env.URL || process.env.DEPLOY_PRIME_URL || '').replace(/\/$/, '');
const { processEmailQueue } = require('./lib/email-queue');
const { atomicUpdateJSON } = require('./lib/store');
const crypto = require('crypto');

function kyivParts() {
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone: 'Europe/Kyiv',
    weekday: 'short',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  });
  const parts = {};
  fmt.formatToParts(new Date()).forEach(p => { parts[p.type] = p.value; });
  const weekdayMap = { Sun: 6, Mon: 0, Tue: 1, Wed: 2, Thu: 3, Fri: 4, Sat: 5 };
  const dayIdx = weekdayMap[parts.weekday];
  const hour = parseInt(parts.hour, 10) % 24;
  const minute = parseInt(parts.minute, 10);
  const dateKey = `${parts.year}-${parts.month}-${parts.day}`;
  return { dayIdx, minutes: hour * 60 + minute, dateKey };
}

// Runs the full reminder check for a single user's data. Nothing here is
// ever shared across users - every key it touches is namespaced by userId.
//
// Unlike a plain "claim once" lock, this also tracks whether the push we
// sent was actually confirmed delivered (see push-ack.js / sw.js). If the
// previous attempt was never acked after RETRY_GRACE_MS, the next cron
// tick (this runs every minute) resends it instead of assuming it landed.
const RETRY_GRACE_MS = 90 * 1000;
async function claimOrRetryPush(s, key) {
  const existing = await s.get(key, { type: 'json' }).catch(() => null);
  const now = Date.now();
  if (!existing) {
    const result = await s.set(key, JSON.stringify({ acked: false, sentAt: now, attempts: 1 }), { onlyIfNew: true });
    return !!result.modified;
  }
  if (existing.acked) return false; // already confirmed delivered - don't resend
  if (now - Number(existing.sentAt || 0) < RETRY_GRACE_MS) return false; // still waiting on an ack, don't spam
  await s.setJSON(key, { acked: false, sentAt: now, attempts: (Number(existing.attempts) || 1) + 1 }).catch(() => {});
  return true;
}

// Mirrors the frontend's resolveSatIndex() in index.html - keep these two in
// sync. Given a Saturday's date, resolves which weekday (0=Mon..4=Fri) its
// make-up lessons actually belong to, honoring a per-date manual override
// before falling back to the anchor-based rotation.
function resolveSatIndex(satRotation, dateStr) {
  if (!satRotation || satRotation.enabled !== true) return 5;
  const ov = satRotation.overrides && satRotation.overrides[dateStr];
  if (Number.isInteger(ov) && ov >= 0 && ov <= 4) return ov;
  if (!satRotation.anchorDate) return 5;
  const anchor = new Date(satRotation.anchorDate + 'T00:00:00');
  const target = new Date(dateStr + 'T00:00:00');
  if (isNaN(anchor.getTime()) || isNaN(target.getTime())) return 5;
  const weeks = Math.round((target - anchor) / (7 * 24 * 60 * 60 * 1000));
  return ((Number(satRotation.anchorDayIdx || 0) + weeks) % 5 + 5) % 5;
}

function pushClaimKey(userId, dateKey, reminderKey, endpoint) {
  const digest = crypto.createHash('sha256').update(String(endpoint)).digest('hex').slice(0, 24);
  return `push-claim:${userId}:${dateKey}:${crypto.createHash('sha256').update(String(reminderKey)).digest('hex').slice(0, 24)}:${digest}`;
}

async function processUser(s, userId, dayIdx, curMins, dateKey) {
  // Check subscriptions first - it's the cheap, small read. Most of the
  // cost here is the schedule-data blob (notes/attachments/etc can be
  // sizeable), so skip it entirely for users with no active push endpoint
  // instead of fetching everything and then discovering there's nothing
  // to do. Eventual consistency is fine for both - reminder windows are
  // several minutes wide already, so a few seconds of staleness never
  // matters here (unlike a strong-consistency read on every save).
  const allSubscriptions = (await s.get(`subscriptions:${userId}`, { type: 'json' })) || [];
  const subscriptions = allSubscriptions.filter(sub => sub && sub.siteOrigin === CURRENT_ORIGIN);
  if (!subscriptions.length) return { sent: 0 };

  const data = await s.get(`schedule-data:${userId}`, { type: 'json' });
  if (!data) return { sent: 0 };

  const effDayIdx = dayIdx === 5 ? resolveSatIndex(data.satRotation, dateKey) : dayIdx;
  let slots = data.schedule?.[effDayIdx] || data.schedule?.[String(effDayIdx)] || [];
  const oneOff = Array.isArray(data.oneOffLessons) ? data.oneOffLessons.filter(x => x && x.date === dateKey) : [];
  slots = slots.concat(oneOff.map(x => ({ ...x, _oneOff: true })));

  const reminders = [];
  for (const sl of slots) {
    if (!sl || typeof sl.time !== 'string' || !/^\d{1,2}:\d{2}$/.test(sl.time)) continue;
    const [h, m] = sl.time.split(':').map(Number);
    if (h > 23 || m > 59) continue;
    const slotMins = h * 60 + m;
    const diff = slotMins - curMins;
    const subj = (data.subjects || []).find(x => x.id === sl.subjId) || { name: 'Пара' };
    const lessonIdentity = String(sl.id || sl.lessonId || sl.subjId || `${sl.time}:${subj.name}`);

    if (data.notif10 && diff <= 10 && diff >= 6) {
      reminders.push({
        key: `lesson:${lessonIdentity}:${sl.time}:10`,
        title: '⏰ ' + subj.name,
        body: `За 10 хвилин · Початок о ${sl.time}${subj.teacher ? ' · ' + subj.teacher : ''}`
      });
    }
    if (data.notif5 && diff <= 5 && diff >= 1) {
      reminders.push({
        key: `lesson:${lessonIdentity}:${sl.time}:5`,
        title: '📚 ' + subj.name,
        body: `За 5 хвилин · Готуйся!${subj.teacher ? ' · ' + subj.teacher : ''}`
      });
    }
    // A reminder right at start time - the 10/5-minute warnings are easy to
    // forget about by the time the lesson actually begins.
    if (data.notif5 && diff <= 0 && diff >= -5) {
      reminders.push({
        key: `lesson:${lessonIdentity}:${sl.time}:0`,
        title: '🔔 ' + subj.name,
        body: `Пара почалася!${subj.teacher ? ' · ' + subj.teacher : ''}`
      });
    }
  }

  // Free, rule-based daily summary - reuses the same push pipeline as lesson
  // and note reminders, so it costs nothing extra (no Groq call). Fires once
  // per day in a short morning window, and only when there's something
  // actually worth flagging (no noise on an uneventful day).
  if (data.dailySummary !== false && curMins >= 450 && curMins <= 459) {
    const openNotes = Array.isArray(data.notes) ? data.notes.filter(n => !n.done && n.deadline) : [];
    const [sy, smo, sd] = dateKey.split('-').map(Number);
    const nowWall = Date.UTC(sy, smo - 1, sd, 0, 0) + curMins * 60000;
    const deadlineWall = (n) => {
      const [dPart, tPart] = String(n.deadline).split('T');
      const [dy, dmo, dd] = String(dPart || '').split('-').map(Number);
      const [dh, dmi] = String(tPart || '23:59').split(':').map(Number);
      if (![dy, dmo, dd, dh, dmi].every(Number.isFinite)) return null;
      return Date.UTC(dy, dmo - 1, dd, dh, dmi);
    };
    const overdue = openNotes.filter(n => { const t = deadlineWall(n); return t !== null && t < nowWall; });
    const dueToday = openNotes.filter(n => { const t = deadlineWall(n); return t !== null && t >= nowWall && t - nowWall <= 24 * 3600 * 1000; });
    let summary = null;
    if (overdue.length) summary = { title: '⚠️ Доброго ранку', body: `У тебе ${overdue.length} прострочен${overdue.length === 1 ? 'а нотатка' : 'і нотатки'}. Варто розібратись сьогодні.` };
    else if (dueToday.length) summary = { title: '⏳ Доброго ранку', body: `${dueToday.length} ${dueToday.length === 1 ? 'дедлайн' : 'дедлайни'} сьогодні/завтра — не забудь.` };
    else if (slots.length >= 5) summary = { title: '🔥 Доброго ранку', body: `Сьогодні ${slots.length} пар — насичений день, не забувай про перерви й воду.` };
    if (summary) reminders.push({ key: `daily-summary:${dateKey}`, title: summary.title, body: summary.body });
  }

  if (Array.isArray(data.notes)) {
    const [ny, nmo, nd] = dateKey.split('-').map(Number);
    const nowWallTs = Date.UTC(ny, nmo - 1, nd, 0, 0) + curMins * 60000;
    for (const note of data.notes) {
      if (note.done || !note.deadline) continue;
      const [dPart, tPart] = String(note.deadline).split('T');
      const [dy, dmo, dd] = String(dPart || '').split('-').map(Number);
      const [dh, dmi] = String(tPart || '23:59').split(':').map(Number);
      if (![dy, dmo, dd, dh, dmi].every(Number.isFinite)) continue;
      const deadlineWallTs = Date.UTC(dy, dmo - 1, dd, dh, dmi);
      const diffMin = Math.round((deadlineWallTs - nowWallTs) / 60000);
      const shortText = String(note.text || 'Нотатка').slice(0, 60);
      if (diffMin <= 1440 && diffMin > 1430) reminders.push({ key: `note:${note.id}:24h`, title: '🔔 Дедлайн завтра', body: shortText });
      else if (diffMin <= 180 && diffMin > 170) reminders.push({ key: `note:${note.id}:3h`, title: '⏳ Дедлайн наближається — 3 години', body: shortText });
      else if (diffMin <= 60 && diffMin > 50) reminders.push({ key: `note:${note.id}:1h`, title: '🚨 Залишилась 1 година! Роби швидше', body: shortText });
      else if (diffMin <= 0) reminders.push({ key: `note:${note.id}:overdue:${dateKey}`, title: '⚠️ Прострочено!', body: shortText });
    }
  }

  let sent = 0;
  const validSubscriptions = [];
  for (const sub of subscriptions) {
    let keep = true;
    for (const msg of reminders) {
      const claimKey = pushClaimKey(userId, dateKey, msg.key, sub.endpoint);
      const claimed = await claimOrRetryPush(s, claimKey);
      if (!claimed) continue;
      try {
        await webpush.sendNotification(sub, JSON.stringify({ title: msg.title, body: msg.body, ackKey: claimKey }));
        sent++;
        await atomicUpdateJSON(`fired-log:${userId}`, { dateKey, fired: [] }, current => {
          const next = current.dateKey === dateKey ? current : { dateKey, fired: [] };
          if (!next.fired.includes(msg.key)) next.fired.push(msg.key);
          return { dateKey, fired: next.fired.slice(-1000) };
        }).catch(() => {});
      } catch (err) {
        if (err.statusCode === 404 || err.statusCode === 410) {
          keep = false;
        } else {
          // Temporary failure: release this subscription/message claim so the
          // next cron tick can retry it. Successful subscriptions remain claimed.
          await s.delete(claimKey).catch(() => {});
        }
      }
    }
    if (keep) validSubscriptions.push(sub);
  }

  if (validSubscriptions.length !== allSubscriptions.length) {
    await atomicUpdateJSON(`subscriptions:${userId}`, allSubscriptions, current => {
      const currentList = Array.isArray(current) ? current : [];
      const bad = new Set(allSubscriptions.filter(x => !validSubscriptions.includes(x)).map(x => x.endpoint));
      return currentList.filter(x => !bad.has(x.endpoint));
    }).catch(() => {});
  }
  return { sent };
}

exports.handler = async (event) => {
  if (!CRON_SECRET) return { statusCode: 503, body: 'Cron secret is not configured' };
  const provided = String(event.headers?.['x-cron-secret'] || event.headers?.['X-Cron-Secret'] || '');
  if (!provided || Buffer.byteLength(provided) !== Buffer.byteLength(CRON_SECRET) || !crypto.timingSafeEqual(Buffer.from(provided), Buffer.from(CRON_SECRET))) {
    return { statusCode: 401, body: 'Unauthorized' };
  }
  if (!VAPID_PUBLIC || !VAPID_PRIVATE) {
    return { statusCode: 503, body: 'VAPID keys not configured' };
  }
  try {
    webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);
    const s = store();
    const { dayIdx, minutes: curMins, dateKey } = kyivParts();

    const { blobs } = await s.list({ prefix: 'schedule-data:' });
    let totalSent = 0, users = 0;

    for (const blob of blobs) {
      const userId = blob.key.slice('schedule-data:'.length);
      if (!userId) continue;
      try {
        const result = await processUser(s, userId, dayIdx, curMins, dateKey);
        totalSent += result.sent;
        users++;
      } catch (userErr) {
        console.error('[check-notifications:user]', userId, userErr?.message || userErr);
      }
    }

    const emailQueue = await processEmailQueue(5).catch(() => ({ sent:0, failed:0, queued:0 }));
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ok: true, users, sent: totalSent, dayIdx, curMins, emailQueue })
    };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: 'Внутрішня помилка сервера' }) };
  }
};
